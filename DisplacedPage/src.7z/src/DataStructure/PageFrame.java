package DataStructure;

/**
 * @author JasonGu
 * @date 2021/12/9 22:20
 */

import java.util.ArrayList;

/**
 * 页框
 */
public abstract class PageFrame {
    private int i;
    //内存页框数
    public ArrayList<SingalPage> pages;

    /**
     *
     * @param pages 虚存列表 容量为40K
     */
    public PageFrame(ArrayList<SingalPage> pages)
    {
        this.pages = pages;
    }

    public void setI(int i) {
        this.i = i;
    }
}
