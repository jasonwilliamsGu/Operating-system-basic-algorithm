package Run;

/**
 * @author JasonGu
 * @date 2021/12/11 9:32
 */

public class Review {
    public Review(){
        learn2();
    }
    public void learn1()
    {
        int i=1;
        double j=2.0000;
        String k="4";
        System.out.println(k+j+i);
    }

    public void learn2()
    {
        boolean b = true;
        System.out.println(!b+"  "+b);
    }
}

class run
{
//    public static void main(String[] args) {
//        new Review();
//    }
}